# The reference implementation

Live at https://pki.sgit.ai/assess/index.html. Two pages, five modules, six custom elements, one
stylesheet, **no dependencies and no build step**. Serve the folder over http and it runs.

```
assess/
  index.html      the assessment — snapshot first, then pick, prune, graph, intent, gap, controls
  library.html    the library explorer — every tree drawn, with its raw JSON beside it
  library.json    THE DATA. Everything the tool stores about a visitor is an identifier from here
  js/model.js     pure logic: build the graph, walk it, compute what is reachable and the delta
  js/graph.js     the SVG renderer — layered DAG, two edge kinds, click to select
  js/store.js     storage: choices only, never answers
  js/components.js six custom elements, no shadow DOM
  js/app.js       state and wiring
  js/library.js   the explorer page
  css/assess.css  this section owns its stylesheet; the site's supplies the tokens
```

## Read `model.js` first

It is the only file with an idea in it. **A capability is reachable if some path of live nodes
reaches it, and the honest label for that capability is the weakest control on that path** — a path
is only as bounded as its least-enforced node. That is why escalation edges matter: they create
paths that go around a setting, and drawing them is what makes the three-tier control test land
instead of being asserted.

Everything in `model.js` is a pure function over `library.json` plus a state object of the shape
`{ products, facts, controls, intent }`. It can be tested by calling it, and it is.

## Four rules to preserve if you extend it

**No free-text input, anywhere.** That is what turns *we do not store what you type* into *there is
nothing to type*. It is also why the acceptor is a role rather than a name — and why this page
cannot meet the pack's own named-acceptor standard, which is recorded rather than hidden.

**No charting library.** The graph is hand-written SVG because a CDN dependency would put a
third-party request on a page whose entire argument is that you can open the network panel and
watch nothing leave. The page makes only same-origin requests, and that is checked.

**No score out of a hundred.** A score gets optimised for how alarming it feels, and an alarming
number with nothing to do about it produces denial rather than change. Show the picture and the
action.

**No risk acceptance.** Acceptor, interval, accept and decline belong to the risk product. This
tool's job ends at *here is what is possible, and here is the delta*.

## How to run it

```
python3 -m http.server 8000
```

It will **not** work from a local folder: a `file://` page gets an opaque origin, so it can neither
fetch its own library nor use browser storage. Both pages detect that and say so by name. It is the
feature that breaks first if the site is ever distributed as a bundle.
