# The reference implementation

Live at https://pki.sgit.ai/assess/index.html. Three files plus a stylesheet block.

| File | What it is |
|---|---|
| `assess/index.html` | The page. Static; the nav and footer are stamped in by the site's build, so the copies here carry stubs. |
| `assess/library.json` | **The public library of pre-computed grant trees.** Everything the tool stores about a visitor is an identifier from this file. Classes of installation, not named products — because naming one means measuring it. |
| `assets/assess.js` | All the logic. ~250 lines, no dependencies, no build step. |
| `assets/assess.css` | Extracted from the site stylesheet; the assessment block only. |

## The two rules it exists to enforce

**Store the choices, not the answers.** A completed assessment describes which agents somebody runs, holding which credentials, with which containment — assembled, that is a plan for attacking them. So what is stored is identifiers from `library.json`, fixed options, and dates derived from them. Implemented as strictly as it can be: **there is no free-text input anywhere on the page.** That turns *we do not store what you type* into *there is nothing to type*, which a reader can confirm by looking.

**A strong threat with a weak answer produces denial rather than change.** Measured, not intuited — defensive response and behaviour change correlate negatively. So there is no score, every case ends on an action the visitor can actually perform, and each action states how many of *their* gaps it closes, computed rather than asserted.

## Things to preserve if you extend it

- No free-text input. The acceptor is a **role**, not a name, for that reason — and it means this page cannot meet the pack's own named-acceptor standard. That conflict is real and recorded (appendix C20, decision 30).
- **No score out of a hundred.** A score gets optimised for how alarming it feels.
- The hosted case ends on a **request, not a remedy**, because its efficacy is zero by construction. Do not invent advice for it.
- If a **scan** is ever added, its output belongs in the visitor's own vault and never in browser storage. That is an argument for building the vault path *before* the scan.

## How to run it

Serve the directory over http and open `assess/index.html`. It will not work from a local folder: a `file://` page gets an opaque origin, so it can neither fetch its own library nor use browser storage. The page detects that and says so by name — and it is the feature that breaks first if the site is ever distributed as a bundle.

```
python3 -m http.server 8000
```
