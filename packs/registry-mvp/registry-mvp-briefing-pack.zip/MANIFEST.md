# Manifest

**44 files · 800 KB · roughly 119k words of markdown.**

At a normal reading pace the supporting material and the pack together are a few hours. The briefing (`README.md`) says what to skim and what to study.

| File | Bytes | Lines |
|---|---:|---:|
| `MANIFEST.md` | 5,155 | 65 |
| `README.md` | 8,838 | 113 |
| `pack/00__LEADING-BRIEF.md` | 10,037 | 110 |
| `pack/01__architecture.md` | 11,490 | 142 |
| `pack/02__schemas.md` | 10,573 | 172 |
| `pack/03__workflows.md` | 9,804 | 139 |
| `pack/04__build-order.md` | 8,157 | 88 |
| `pack/05__diagrams.md` | 6,053 | 140 |
| `pack/07__tabletop-exercise.md` | 7,417 | 71 |
| `pack/08__ux-mockups.md` | 33,801 | 498 |
| `pack/09__wardley-maps.md` | 23,884 | 327 |
| `pack/10__user-stories-and-features.md` | 27,360 | 346 |
| `pack/11__observability.md` | 25,162 | 303 |
| `pack/12__grant-tree-and-control-labels.md` | 22,453 | 253 |
| `pack/13__keys-and-signatures.md` | 18,394 | 184 |
| `pack/14__user-assessment.md` | 18,162 | 186 |
| `pack/99__change-control.md` | 41,909 | 252 |
| `pack/README.md` | 4,003 | 27 |
| `reference-implementation/README.md` | 2,621 | 32 |
| `reference-implementation/assess/index.html` | 12,648 | 177 |
| `reference-implementation/assess/library.json` | 16,663 | 164 |
| `reference-implementation/assets/assess.css` | 7,027 | 103 |
| `reference-implementation/assets/assess.js` | 22,276 | 396 |
| `supporting/briefs/v0.33.59__arch-brief__relay-pattern-encryption-signing-and-ordering-are-three-mechanisms.md` | 21,707 | 224 |
| `supporting/briefs/v0.33.59__strategy-brief__nhi-site-two-populations-industry-answers-only-agents-you-run.md` | 20,055 | 219 |
| `supporting/briefs/v0.33.59__strategy-brief__pki-sgit-keyserver-failure-append-only-ownership-rule.md` | 20,715 | 219 |
| `supporting/briefs/v0.33.60__arch-brief__agent-enrolment-without-borrowed-authority-append-lane-is-the-narrow-door.md` | 18,509 | 220 |
| `supporting/briefs/v0.33.60__arch-brief__append-lane-is-shipped-and-account-less-four-tiers-and-five-corrections.md` | 19,205 | 203 |
| `supporting/briefs/v0.33.60__arch-brief__service-twin-agent-never-holds-the-credential-closes-the-authorised-misuse-boundary.md` | 21,434 | 245 |
| `supporting/briefs/v0.33.60__briefing-pack__agent-identity-mandate-and-execution.md` | 9,625 | 126 |
| `supporting/briefs/v0.33.60__cross-team-brief__pki-site-review-mandate-is-the-gap-registry-is-the-missing-half.md` | 16,470 | 196 |
| `supporting/briefs/v0.33.60__strategy-brief__bootstrap-trap-every-workaround-hands-over-a-larger-identity.md` | 15,653 | 185 |
| `supporting/briefs/v0.33.61__arch-brief__a-secret-is-defined-by-expectation-a-signature-by-scarcity.md` | 23,901 | 213 |
| `supporting/briefs/v0.33.61__arch-brief__end-to-end-flow-is-the-august-worked-example-grant-tree-needs-control-labels.md` | 32,151 | 309 |
| `supporting/briefs/v0.33.61__arch-brief__every-trust-edge-is-a-two-way-conversation-notary-signed-once-vs-checked-every-time.md` | 23,444 | 224 |
| `supporting/briefs/v0.33.61__arch-brief__history-is-the-append-only-log-objects-immutable-reference-is-not.md` | 26,571 | 254 |
| `supporting/briefs/v0.33.61__arch-brief__observability-is-the-usage-graph-check-events-in-the-issuers-lane-a-verification-is-not-a-use.md` | 25,424 | 248 |
| `supporting/briefs/v0.33.61__arch-brief__register-was-designed-in-june-published-keypairs-are-fixtures-not-identities.md` | 35,113 | 279 |
| `supporting/briefs/v0.33.61__cross-team-brief__site-access-report-three-findings-closed-composition-gap-moved-up-a-layer.md` | 24,911 | 219 |
| `supporting/briefs/v0.33.61__dev-brief__register-ui-every-edge-carries-a-verification-badge-policy-is-a-query.md` | 26,828 | 254 |
| `supporting/briefs/v0.33.61__dev-brief__user-section-is-a-conformance-test-store-the-choices-not-the-answers.md` | 26,162 | 243 |
| `supporting/briefs/v0.33.61__strategy-brief__grant-is-not-mandate-the-gap-is-the-exposure-nobody-accepted.md` | 32,154 | 291 |
| `supporting/index.md` | 5,976 | 112 |
| `supporting/llms.txt` | 19,929 | 282 |

## Not included, and where to find it

- **The site itself** — https://pki.sgit.ai. The pack is one section of it; the arguments it rests on (the 2019 keyserver failure, the four rules, the bootstrap trap, what already ships) are pages there, and `supporting/llms.txt` links every one.
- **The wider corpus** — the briefs here are the ones addressed to this site. The rest of the project record is not public and is not needed to assess the pack.
- **`sgit` itself** — the CLI this design sits on, documented at https://sgit.ai/docs/pki. Its shipped PKI surface is RSA-OAEP 4096 and ECDSA P-256, with **no revocation and no directory** — which is the absence this whole pack exists to fill.

## Provenance

Assembled from the pki.sgit.ai repository at site v0.1.17. Every file is CC BY 4.0.

Scanned before packaging for customer names, security finding identifiers, private keys, cloud credentials, access tokens, email addresses and vault-key-shaped strings. **None present.** The pack contains no live capability of any kind, which is a rule the registry design itself carries: the register never holds a usable credential.
