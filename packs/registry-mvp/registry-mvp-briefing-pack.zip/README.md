# Briefing: implement the registry MVP

**For:** a fresh Claude session (or any engineer) picking this up cold
**From:** the pki.sgit.ai site agent
**Pack version:** registry MVP draft-1 + appendix, as at site v0.1.17 · 20 August 2026
**Live site:** https://pki.sgit.ai · pack hub: https://pki.sgit.ai/packs/registry-mvp/index.html

---

## Your task, in one paragraph

Read the supporting material, then read the dev pack in detail, then **tell us whether you have what you need to implement it.** Not a plan you are confident about because you filled the gaps yourself — an honest answer. If you have everything, say so and show the plan. If you do not, list the questions that must be answered before a line is written, each one tied to what it blocks. **A short list of real blockers is a better result than a long plan built on guesses**, and this pack has enough deliberately open decisions that a confident plan is more likely to mean you missed them than that they are not there.

Do not start implementing. This step ends with a readiness report.

---

## Read in this order

### 1 · Supporting material — where the argument comes from (`supporting/`)

Start here, and skim rather than study. You are building context for the pack, not learning the design yet.

- **`supporting/llms.txt`** — the site's machine-readable front door. The fastest orientation available: what the site claims, in what order, with links.
- **`supporting/index.md`** — the home page as markdown.
- **`supporting/briefs/`** — the corpus briefs the pack is derived from, in full. These are the *primary sources*. Where a pack document and a brief disagree, the brief is the corpus's position and the pack is the site agent's reading of it. Nine of them, all v0.33.61 (20 August), plus the earlier ones that set up the vocabulary.

**Two things to notice while you read the briefs**, because they explain the pack's shape:

- The corpus **supersedes rather than rewrites**. A published document is never silently edited; corrections are recorded elsewhere and the original stands. This is a rule taken from a 2019 keyserver failure and it is load-bearing, not stylistic.
- Several briefs **correct earlier ones from the same day**. Reading them out of order will leave you with a superseded definition of *grant*. The pack's appendix is the map of which.

### 2 · The dev pack — the thing to assess (`pack/`)

Read all of it. It is long, and skipping the tensions and open questions defeats the purpose of this exercise, since those are where your questions will come from.

Reading order is in `pack/README.md`. Two notes on it:

- **`99__change-control.md` is the appendix, and it is not optional.** It carries twenty-three corrections and thirty-six decisions. Read it **second** if you intend to build from documents 00–04, so you read those with the errata in hand — several of their definitions are superseded. Read it **last** if you are reading straight through. Never not at all: without it you will implement `grant` as draft-1 defined it, and draft-1's definition was replaced on the day it shipped.
- **`14__user-assessment.md` describes something that already exists.** Everything else is a design.

### 3 · The reference implementation (`reference-implementation/`)

The one shipped surface, live at https://pki.sgit.ai/assess/index.html. Read the source. It is small, and it is the only evidence in this pack that its own corrections are buildable rather than merely defensible — it implements the grant tree, the three-tier control test, the prohibition rendering and the metric family, once each.

**Be clear about what it is not.** It is a *consumer* of the registry's model, not a piece of the registry. It renders grant trees and mandates and stores nothing on anybody's behalf. **The registry itself is entirely unbuilt.**

---

## What you are assessing against

The pack asks for a public key registry on vaults, in five phases, and the definition of done for each is a **fresh-session acceptance test** — see `pack/04__build-order.md`. Your report should be able to answer, per phase:

1. Is the design specified precisely enough to build without inventing?
2. Which open decisions block it, and what would each unblock?
3. What does it depend on that does not exist yet — in the shipped platform, in tooling, or in a vocabulary nobody has written?
4. What would you build first, and what is the first thing that could prove the design wrong?

---

## Six things that will trip you up

Listed because each one has already cost somebody time, not to be exhaustive.

1. **The definition of `grant` changed on the day draft-1 shipped.** Draft-1: one capability instance issued under a mandate. The corpus: *what a credential technically permits, whether or not anybody wrote it down.* The gap to the mandate is **excess authority**. Appendix C1. Document 02's schema still carries the old field names, deliberately, and says so.

2. **A grant is a tree, not a list, and the label on each node is the point.** Appendix C16 and document 12. The test is general: *a control bounds a grant only when it is enforced by something the grant does not include.* If you implement the tree and not the labels you have built a diagram of assertions.

3. **Several "decided" things are proposals.** The decisions register at the end of the appendix says which. Roughly a third are open, and at least four of them block phase 3 outright — including the capability vocabulary, without which the *shortfall* region cannot be computed at all.

4. **Some absences are deliberate and must not be helpfully filled.** The registry never contains a live capability, only hashes. The append lane's acknowledgement is blind, and pending is indistinguishable from declined by design. The index carries no authority. If your plan improves any of these, you have removed a security property rather than a limitation.

5. **The assessment stores choices, never answers.** No free-text input exists on that page, on purpose. If you extend it, that rule is the first thing to preserve — and the moment a *scan* is added, its output must go to the visitor's own vault and never to browser storage.

6. **Two dependencies are proposed rather than shipped**, and the pack marks both: the append-lane address derivation (so tokens are agreed out of band today), and whether a lane with no anchors configured accepts any token holder — which gates the entire observability layer's coverage. Do not plan around either as if it were available.

---

## What to hand back

A single markdown document. No code.

```
1. WHAT I READ            what you actually got through, and what you skipped
2. WHAT I UNDERSTAND      the design in your own words, in under a page.
                          If you cannot, that is the finding.
3. READY OR NOT           per phase (0-4): ready / blocked / partly.
                          Say which, and why.
4. BLOCKING QUESTIONS     each one: the question, what it blocks, what you would
                          assume if forced, and what breaks if the assumption is
                          wrong. Ordered by what they block, not by difficulty.
5. NON-BLOCKING GAPS      things you would want and could start without
6. WHAT I WOULD BUILD     only if section 3 has a "ready". Otherwise say so.
   FIRST
7. WHERE I THINK THE      you are a fresh reader; that is the one thing you have
   PACK IS WRONG          that we do not. Disagreements are the most valuable
                          output of this exercise
```

**Section 7 is not a courtesy.** Every document in this pack was written by an agent with the whole corpus in context, and that is exactly the condition under which a design becomes internally consistent and wrong. A fresh reader who finds the pack unclear has found a defect in the pack, not in themselves — say so plainly.

## What good looks like

> *"Phases 0 and 1 are buildable today. Phase 2 needs one decision — out-of-band token distribution — and I would not start it without one. Phase 3 is blocked on the capability vocabulary and I can show why: three documents assume `repo.pull-request.create` and none defines what a capability name is. Here are four questions, ordered. Here is what I would build first, and here is the first thing that could prove the design wrong."*

That is a better outcome than a full implementation plan, and it is the one being asked for.

---

## Provenance and licence

Everything here is CC BY 4.0. The pack is site-agent authored and **has not been adopted** by the project lead — it carries no corpus version, which is why the appendix's decisions register exists. Nothing in this zip is confidential, and nothing in it describes any customer, any live finding, or any credential. It was scanned for all three before packaging.
